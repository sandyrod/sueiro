@extends('layouts.dashboard')
@section('content')
    @livewire('home')
@endsection
    